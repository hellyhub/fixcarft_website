FIXCRAFT WEBSITE
=================

This is a responsive static website inspired by the general structure of modern handyman-service websites. It is NOT a copy of FixTman and uses original FixCraft wording/layout.

FILES
- index.html   Main website
- styles.css   Design and responsive layout
- script.js    Menu + quote form behavior

EDITING
1. Open index.html in a text editor.
2. Replace the Instagram # link near the bottom with your actual Instagram URL.
3. Replace gallery sample boxes with your own project photos if desired.
4. Change any service wording you want.

QUOTE FORM
The form opens the customer's SMS app and prepares a message to FixCraft at 510-397-8880.

BUSINESS DETAILS USED
- Brand: FixCraft
- Phone: 510-397-8880
- Area: Bay Area, California
- Services emphasize assembly, mounting and minor handyman work.
- Painting and appliance/fan services are not included.

LEGAL/BRANDING
The site is designed as an original FixCraft website concept. It should not be represented as affiliated with FixTman.
